from django.contrib import admin
from .models import Course, Instructor, Lesson

# Register your models here.